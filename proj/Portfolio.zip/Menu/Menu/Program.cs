﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Menu
{
    class Program
    {
        static void Main(string[] args)
        {
            int opc;
            do
            {
                //Mostrar a lista de opções
                Console.Clear();
                Console.SetCursorPosition(30, 0);
                Console.WriteLine("M E N U   P R I N C I P A L");
                Console.SetCursorPosition(0, 1);
                Console.Write(new string('=', 80));

                Console.SetCursorPosition(25, 5);
                Console.Write("[1] Calculos ");
                Console.SetCursorPosition(25, 6);
                Console.Write("[2] Sucessor/Antecessor ");
                Console.SetCursorPosition(25, 7);
                Console.Write("[3] Compara números ");
                Console.SetCursorPosition(25, 8);
                Console.Write("[4] Tabuada ");
                Console.SetCursorPosition(25, 9);
                Console.Write("[5] Média");
                Console.SetCursorPosition(25, 10);
                Console.Write("[6] Bhaskara");
                Console.SetCursorPosition(25, 11);
                Console.Write("[7] Fases da Vida");
                Console.SetCursorPosition(25, 12);
                Console.Write("[8] IMC");
                Console.SetCursorPosition(25, 13);
                Console.Write("[9] adivinha");
                Console.SetCursorPosition(25, 14);
                Console.Write("[10] compara_letras ");
                Console.SetCursorPosition(25, 15);
                Console.Write("[11] Zeni_polar ");
                Console.SetCursorPosition(25, 16);
                Console.Write("[12] Forca");
                Console.SetCursorPosition(25, 17);
                Console.Write("[13] Extenso");
                Console.SetCursorPosition(25, 18);
                Console.Write("[14] Fim");



                Console.SetCursorPosition(0, 19);
                Console.Write(new string('=', 80));
                Console.SetCursorPosition(0, 21);
                Console.Write(new string('=', 80));
                //Receber a escolha do usuário
                Console.SetCursorPosition(25, 20);
                Console.Write("Digite o n° de sua escolha: ");
                opc = int.Parse(Console.ReadLine());
                //Decidir o que fazer
                switch (opc)
                {
                    case 1:
                        {
                            Calculadora();
                            break;
                        }
                    case 2:
                        {
                            Sucessor_Antecessor();
                            break;
                        }
                    case 3:
                        {
                            compara_numeros();
                            break;
                        }
                    case 4:
                        {
                            Tabuada();
                            break;
                        }
                    case 5:
                        {
                            média();
                            break;
                        }

                    case 6:
                        {
                            Bhaskara();
                            break;
                        }
                    case 7:
                        {
                            Fases_da_vida();
                            break;
                        }
                    case 8:
                        {
                            IMC();
                            break;
                        }
                    case 9:
                        {
                            adivinha();
                            break;
                        }

                    case 10:
                        {
                            compara_letras();
                            break;
                        }
                    case 11:
                        {
                            Zeni_polar();
                            break;
                        }
                    case 12:
                        {
                            forca();
                            break;
                        }
                    case 13:
                        {
                            extenso();
                            break;
                        }
                    case 14:
                        {
                            break;
                        }
                    default:
                        {
                            Console.SetCursorPosition(25, 20);
                            Console.Write("[*** Opção inválida ***]");
                            break;
                        }
                }//fecha o switch

                Console.ReadKey();

            } while (opc != 10); //fecha o do{

        }//fecha o Main()

        static void Sucessor_Antecessor()
        {
            int a, b, c;
            string vResposta;
            Console.Clear();
            do
            {
                Console.WriteLine("Digite um número : ");
                a = int.Parse(Console.ReadLine());
                c = a + 1;
                b = a - 1;

                Console.WriteLine("o antecessor e o sucessor é : " + b + " e " + c);
                Console.WriteLine("Deseja ver mais cáculos?(S/N)");
                vResposta = Console.ReadLine();
            } while (vResposta.ToUpper() == "S" || vResposta.ToUpper() == "n");
            Console.ReadKey();
        }

        static void Calculadora()
        {
            double d, m, n, o;

            int a, s, y;
            string vResposta;
            Console.Clear();

            do
            {


                Console.Write("[1] soma [2]subtração [3] multiplicação [4] divisão : ");
                y = int.Parse(Console.ReadLine());
                Console.WriteLine("digite um numero: ");
                a = int.Parse(Console.ReadLine());
                Console.WriteLine("digite outro numero: ");
                s = int.Parse(Console.ReadLine());

                d = a - s;
                m = a + s;
                n = a * s;
                o = a / s;
                if (y == 1)
                {
                    m = a + s;
                    Console.WriteLine("o resultado é " + m);

                }
                else if (y == 2)
                {
                    d = a - s;
                    Console.WriteLine("o resultado é " + d);
                }
                else if (y == 3)
                {
                    n = a * s;
                    Console.WriteLine("o resultado é " + n);

                }
                else if (y == 4)
                {
                    o = a / s;
                    Console.WriteLine("o resultado é " + o);
                }
                Console.WriteLine("Deseja calcular novamente (S/N)?");
                vResposta = Console.ReadLine();

            } while (vResposta.ToUpper() == "S" || vResposta.ToUpper() == "n");

            Console.ReadKey();
        }
        static void Tabuada()
        {
            int i, N;
            string vResposta;
            Console.Clear();
            do
            {

                Console.Write("Digite um número: ");
                N = int.Parse(Console.ReadLine());
                for (i = 1; i <= 10; i++)
                {
                    Console.WriteLine(N + "x" + i + "=" + N * i);
                    Thread.Sleep(500);

                }
                Console.WriteLine("Deseja ver mais tabuadas(S/N)");
                vResposta = Console.ReadLine();
            } while (vResposta.ToUpper() == "S" || vResposta.ToUpper() == "n");
            Console.ReadKey();
        }

        static void compara_numeros()
        {
            int a, b;
            string vResposta;
            Console.Clear();
            do
            {


                Console.Write("Digite um número:");
                a = int.Parse(Console.ReadLine());


                Console.Write("Digite outro número:");
                b = int.Parse(Console.ReadLine());
                if (a > b)
                {

                    Console.Write(+a + " É maior que " + b);
                }
                else if (b > a)
                {

                    Console.Write(+b + " É maior que " + a);

                }
                else
                {

                    Console.Write("os numeros" + a + " e " + b + "são iguais");
                }

                Console.Write("Deseja continuar calculando (S/N)?");

                vResposta = Console.ReadLine();
            } while (vResposta.ToUpper() == "S" || vResposta.ToUpper() == "n");
            Console.ReadKey();
        }
        static void Bhaskara()
        {
            double a, b, c, D, x1, x2;
            string vResposta;
            Console.Clear();
            do
            {
                Console.WriteLine("Digite um número");
                a = double.Parse(Console.ReadLine());

                Console.WriteLine("Digite outro número");
                b = double.Parse(Console.ReadLine());

                Console.WriteLine("Digite mais um número");
                c = double.Parse(Console.ReadLine());

                D = b * b - (4 * a * c);

                Console.WriteLine("Delta é igual a " + D);

                x1 = -b - Math.Sqrt(D) / 2 * a;
                x2 = -b + Math.Sqrt(D) / 2 * a;

                Console.WriteLine("o resultado é " + x1);
                Console.WriteLine("o resultado do outro x é " + x2);

                Console.Write("Deseja continuar calculando (S/N)?");

                vResposta = Console.ReadLine();

            } while (vResposta.ToUpper() == "S" || vResposta.ToUpper() == "n");


            Console.ReadKey();
        }
        static void Fases_da_vida()
        {
            int Idade, Data_de_Nascimento, Data_Atual;
            string vResposta;
            Console.Clear();
            do
            {

                Console.WriteLine("Digite o ano atual: ");
                Data_Atual = int.Parse(Console.ReadLine());
                Console.WriteLine("Digite o ano do seu nascimento: ");
                Data_de_Nascimento = int.Parse(Console.ReadLine());
                Idade = Data_Atual - Data_de_Nascimento;
                Console.WriteLine("Você tem " + Idade + " anos");
                if ((Idade >= 0) && (Idade <= 10))
                    Console.WriteLine("Você é uma criança");
                else if ((Idade > 10) && (Idade <= 15))
                    Console.WriteLine("Você é um(a) pré-adolescente");
                else if ((Idade > 15) && (Idade <= 18))
                    Console.WriteLine("Você é um(a) adolescente");
                else if ((Idade > 18) && (Idade <= 30))
                    Console.WriteLine("Você é um(a) jovem");
                else if ((Idade > 31) && (Idade < 59))
                    Console.WriteLine("Você é um adulto");
                else
                    Console.WriteLine("Você está na terceira idade");
                Console.WriteLine("Você deseja continuar calculando (S/N)?");
                vResposta = Console.ReadLine();
            } while (vResposta.ToUpper() == "S" || vResposta.ToUpper() == "n");

            Console.ReadKey();

        }
        static void IMC()
        {
            double P, A, R, I;
            string vResposta;
            Console.Clear();
            do
            {

                Console.WriteLine("Digite seu altura: ");
                A = double.Parse(Console.ReadLine());

                I = A * A;



                Console.WriteLine("Digite sua peso: ");
                P = double.Parse(Console.ReadLine());


                R = P / I;

                Console.WriteLine("Seu IMC é: " + R);


                if (R < 17)
                {
                    Console.WriteLine("Você está muito abaixo do peso");
                }
                else if ((R >= 17) && (R < 18.5))
                {
                    Console.WriteLine("Você está abaixo do peso");
                }

                else if ((R >= 18.5) && (R < 25))
                {
                    Console.WriteLine("Você está no peso ideal, muito bem! ");
                }
                else if ((R >= 25) && (R < 30))
                {
                    Console.WriteLine("Você está acima do peso");
                }
                else if ((R >= 30) && (R < 35))
                {
                    Console.WriteLine("Você apresenta o primeiro grau da obsidade ");
                }
                else if ((R >= 35) && (R < 40))
                {
                    Console.WriteLine("Você apresenta o segundo grau da obsidade");
                }
                else
                {
                    Console.WriteLine("Você apresenta o terceiro grau da obsidade");
                }
                Console.WriteLine("Você deseja continuar calculando (S/N)?");
                vResposta = Console.ReadLine();
            } while (vResposta.ToUpper() == "S" || vResposta.ToUpper() == "n");



            Console.ReadKey();
        }
        static void par_ímpar()
        {
            double a, r;
            string vResposta;
            Console.Clear();
            do
            {
                Console.WriteLine("Informe um número: ");
                a = double.Parse(Console.ReadLine());
                r = a % 2;
                if (r == 0)
                {
                    Console.WriteLine(a + " é par");
                }
                else
                    Console.WriteLine(a + " é ímpar ");
                Console.WriteLine("Você deseja continuar calculando (S/N)?");
                vResposta = Console.ReadLine();
            } while (vResposta.ToUpper() == "S" || vResposta.ToUpper() == "n");

            Console.ReadKey();

        }
        static void média()
        {

            double a, b, c, d, Média, soma;
            string vResposta;
            Console.Clear();
            do
            {


                Console.Clear();
                Console.Write("Informe a nota do primeiro bimestre: ");
                a = double.Parse(Console.ReadLine());
                Console.Write("Informe a nota do segundo bimestre: ");
                b = double.Parse(Console.ReadLine());
                Console.Write("Informe a nota do terceiro bimestre: ");
                c = double.Parse(Console.ReadLine());

                Console.Write("Informe a nota do quarto bimestre: ");
                d = double.Parse(Console.ReadLine());

                soma = a + b + c + d;
                Média = soma / 4;





                if ((Média >= 0) && (Média < 5))
                    Console.WriteLine("Sua média é I");
                else if ((Média >= 5) && (Média < 7.5))
                    Console.WriteLine("Sua média é R");
                else if ((Média >= 7.5) && (Média < 9.5))
                    Console.WriteLine("Sua média é B");
                else
                    Console.WriteLine("Sua média é MB");
                Console.WriteLine("Deseja continuar vendos as médias (S/N)?");
                vResposta = Console.ReadLine();

            } while (vResposta.ToUpper() == "S" || vResposta.ToUpper() == "n");


            Console.ReadKey();
        }
        static void adivinha()
        {
            int N, P, C;
            string vResposta;
            Console.Clear();
            Random gerador = new Random();
            N = gerador.Next(1, 11);
            C = 0;
            do
            {
                C = C + 1;
                Console.WriteLine("Digite seu palpite: ");
                P = int.Parse(Console.ReadLine());
                if (P > N)
                    Console.WriteLine("Seu Palpite é maior");
                else if (P < N)
                    Console.WriteLine("Seu Palpite é menor");
                else
                    Console.WriteLine("Parabéns você acertou na " + C + "ª vez");
                Console.WriteLine("Deseja continuar vendos as médias (S/N)?");
                vResposta = Console.ReadLine();
            } while (P != N || vResposta.ToUpper() == "S" || vResposta.ToUpper() == "n");
            Console.ReadKey();
        }
        static void compara_letras()
        {
            string Letra, Palavra;
            int Tamanho, x, contVog = 0, contCon = 0;

            Console.WriteLine("Informe a palavra: ");
            Palavra = Console.ReadLine();

            Tamanho = Palavra.Length;



            for (x = 0; x <= Tamanho - 1; x++)
            {

                Letra = Palavra.Substring(x, 1);
                switch (Letra.ToLower())
                {

                    case "a":
                        {
                            contVog++;
                        }
                        break;

                    case "e":
                        {
                            contVog++;
                        }
                        break;
                    case "i":
                        {
                            contVog++;
                            break;
                        }
                    case "o":
                        {
                            contVog++;
                            break;
                        }
                    case "u":
                        {
                            contVog++;
                        }
                        break;

                    case " ":
                        {
                            ;
                        }
                        break;

                    default:
                        {
                            contCon++;
                        }
                        break;
                }


            }
            Console.WriteLine("Foram informados " + contVog + " vogais");
            Console.WriteLine("Foram informados " + contCon + " consoantes");

            Console.ReadKey();
        }
        static void Zeni_polar()
        {
            janela(0, 0, 4, 115);
            Zenit();

        }
        static void Zenit()
        {
            string Letra, PalavraCodificada, Palavra;
            int Tamanho, x;


            Console.Clear();
            janela(0, 0, 4, 115);
            Console.SetCursorPosition(3, 1); Console.Write("Informe a palavra ou frase que você quer codificar: ");


            Palavra = Console.ReadLine();

            Tamanho = Palavra.Length;

            PalavraCodificada = ("");

            for (x = 0; x <= Tamanho - 1; x++)
            {

                Letra = Palavra.Substring(x, 1);
                switch (Letra.ToLower())
                {

                    case "z":
                        {
                            PalavraCodificada = PalavraCodificada + "p";
                        }
                        break;

                    case "e":
                        {
                            PalavraCodificada = PalavraCodificada + "o";
                        }
                        break;

                    case "n":
                        {
                            PalavraCodificada = PalavraCodificada + "l";
                        }
                        break;

                    case "i":
                        {
                            PalavraCodificada = PalavraCodificada + "a";
                        }
                        break;

                    case "t":
                        {
                            PalavraCodificada = PalavraCodificada + "r";
                        }
                        break;

                    case "p":
                        {
                            PalavraCodificada = PalavraCodificada + "z";
                        }
                        break;

                    case "o":
                        {
                            PalavraCodificada = PalavraCodificada + "e";
                        }
                        break;

                    case "l":
                        {
                            PalavraCodificada = PalavraCodificada + "n";
                        }
                        break;

                    case "a":
                        {
                            PalavraCodificada = PalavraCodificada + "i";
                        }
                        break;

                    case "r":
                        {
                            PalavraCodificada = PalavraCodificada + "t";
                        }
                        break;

                    default:
                        {
                            PalavraCodificada = PalavraCodificada + Letra;
                        }
                        break;

                }

            }
            Console.SetCursorPosition(3, 2);
            Console.WriteLine(PalavraCodificada);
            Console.SetCursorPosition(3, 3);
            Console.ReadKey();

        }
        static void forca()
        {

            int opc;
            do
            {

                Console.Clear();
                Console.SetCursorPosition(30, 2);
                Console.WriteLine("Jogo da Forca");
                Console.SetCursorPosition(0, 1);
                Console.Write(new string('=', 80));

                Console.SetCursorPosition(25, 5);
                Console.Write("[1] Um Jogador");
                Console.SetCursorPosition(25, 6);
                Console.Write("[2] Dois Jogadores");
                Console.SetCursorPosition(25, 7);
                Console.Write("[3] Fim");

                Console.SetCursorPosition(0, 9);
                Console.Write(new string('=', 80));
                Console.SetCursorPosition(0, 11);
                Console.Write(new string('=', 80));

                Console.SetCursorPosition(25, 10);
                Console.Write("Digite o n° de sua escolha: ");
                opc = int.Parse(Console.ReadLine());

                switch (opc)
                {
                    case 1:
                        {
                            Um_Jogador();
                            break;
                        }
                    case 2:
                        {
                            Dois_Jogadores();
                            break;
                        }
                    case 3:
                        {
                            break;
                        }
                    default:
                        {
                            Console.SetCursorPosition(25, 20);
                            Console.Write("[*** Opção inválida ***]");
                            break;
                        }
                }

                Console.ReadKey();

            } while (opc != 3);

            Console.ReadKey();
        }

        static void Um_Jogador()
        {
            int i = 0, vTam, x, vAcertos = 0, vErros = 0, vPosicao = 16;
            string vLetra, vletraD, vAtual = "", vAnterior, vLetraA = "", letrasjadigitas;
            bool vAcertou;

            Console.Clear();

            Random aleatorio = new Random();

            string[] vPalavra = new string[25];
            string[] vDica = new string[25];
            vPalavra[0] = "jacare";
            vDica[0] = "animal";
            vPalavra[1] = "melancia";
            vDica[1] = "fruta";
            vPalavra[2] = "camisa";
            vDica[2] = "roupa";
            vPalavra[3] = "onibus";
            vDica[3] = "veículo";
            vPalavra[4] = "banana";
            vDica[4] = "fruta";
            vPalavra[5] = "coala";
            vDica[5] = "animal";
            vPalavra[6] = "cueca";
            vDica[6] = "roupa";
            vPalavra[7] = "carro";
            vDica[7] = "veículo";
            vPalavra[8] = "moto";
            vDica[8] = "veículo";
            vPalavra[9] = "urso";
            vDica[9] = "animal";
            vPalavra[10] = "cachorro";
            vDica[10] = "animal";
            vPalavra[11] = "abacaxi";
            vDica[11] = "fruta";
            vPalavra[12] = "cavalo";
            vDica[12] = "animal";
            vPalavra[13] = "bicicleta";
            vDica[13] = "veículo";
            vPalavra[14] = "tomate";
            vDica[14] = "fruta";
            vPalavra[15] = "batata";
            vDica[15] = "tubérculo";
            vPalavra[16] = "baleia";
            vDica[16] = "animal";
            vPalavra[17] = "gato";
            vDica[17] = "animal";
            vPalavra[18] = "patinete";
            vDica[18] = "veículo";
            vPalavra[19] = "azul";
            vDica[19] = "cor";
            vPalavra[20] = "vermelho";
            vDica[20] = "cor";
            vPalavra[21] = "ciano";
            vDica[21] = "cor";
            vPalavra[22] = "rosa";
            vDica[22] = "cor";
            vPalavra[23] = "cadeira";
            vDica[23] = "móvel";
            vPalavra[24] = "mesa";
            vDica[24] = "móvel";
            i = aleatorio.Next(0, 25);
            vTam = vPalavra[i].Length;

            Console.Write("A palavra sorteada tem {0} letras", vTam);

            Console.SetCursorPosition(64, 0);
            Console.Write("Dica: " + vDica[i]);

            Console.SetCursorPosition(0, 2);
            Console.Write("┌──────┐");
            Console.SetCursorPosition(0, 3);
            Console.Write("│      ");
            Console.SetCursorPosition(0, 4);
            Console.Write("│     ");
            Console.SetCursorPosition(0, 5);
            Console.Write("│      ");
            Console.SetCursorPosition(0, 6);
            Console.Write("│     ");
            Console.SetCursorPosition(0, 7);
            Console.Write("│");
            Console.SetCursorPosition(0, 8);
            Console.Write("┴");

            for (x = 0; x < vTam; x++)
            {
                Console.SetCursorPosition(26 + x, 7);
                vAtual = vAtual + "-";

            }

            Console.Write(vAtual);

            do
            {
                Console.SetCursorPosition(0, 1);
                Console.Write("Digite uma letra: ");
                vletraD = Console.ReadLine();
                letrasjadigitas = vletraD;

                vPosicao = vPosicao + 4;
                vAnterior = vAtual;
                vAtual = "";
                vAcertou = false;

                Console.SetCursorPosition(25, 20);
                Console.Write("letras digitadas : ");

                Console.SetCursorPosition(vPosicao, 21);
                Console.Write(letrasjadigitas + " | ");


                for (x = 0; x < vTam; x++)
                {
                    vLetra = vPalavra[i].Substring(x, 1);
                    vLetraA = vAnterior.Substring(x, 1);
                    if ((vletraD == vLetra) && (vLetraA == "-"))
                    {

                        vAtual = vAtual + vLetra;
                        vAcertos = vAcertos + 1;
                        vAcertou = true;
                    }


                    else
                    {
                        vAtual = vAtual + vLetraA;
                    }

                }

                if (false == vAcertou)
                {
                    vErros = vErros + 1;
                    MostraCorpo(vErros);

                    Console.SetCursorPosition(20, 10);
                    Console.Write("Erros: ");

                    Console.SetCursorPosition(vPosicao, 11);
                    Console.Write(vletraD + " | ");

                }

                Console.SetCursorPosition(25 + x, 7);
                Console.Write(vAtual);

                if (vAcertos == vTam)
                {
                    Console.SetCursorPosition(25, 13);
                    Console.WriteLine("Parabéns, você ganhou !!!");
                }

                if (vErros == 6)
                {
                    Console.SetCursorPosition(25, 13);
                    Console.WriteLine(" Você perdeu !!!");
                    Console.SetCursorPosition(25, 14);
                    Console.WriteLine("A palavra era " + vPalavra[i]);
                }
                if (letrasjadigitas.Contains(vLetraA))
                {
                    Console.SetCursorPosition(25, 5);
                    Console.Write("Você já digitou essa letra !!!");
                    Thread.Sleep(1000);
                    Console.SetCursorPosition(25, 5);
                    Console.Write("                              ");
                }

            } while ((vErros != 6) && (vAcertos != vTam));

            Console.ReadKey();

        }

        static void Dois_Jogadores()
        {
            int i = 0, vTam, x, vAcertos = 0, vErros = 0, vPosicao = 16;
            string vLetra, vletraD, vAtual = "", vAnterior, vLetraA = "", vpalavra = "", palavrajadigitada = "";
            bool vAcertou;

            Console.Clear();




            Console.Write("Digite uma palavra para o seu amigo: ");
            vpalavra = Console.ReadLine();

            vTam = vpalavra.Length;

            Console.SetCursorPosition(0, 2);
            Console.Write("┌──────┐");
            Console.SetCursorPosition(0, 3);
            Console.Write("│      ");
            Console.SetCursorPosition(0, 4);
            Console.Write("│     ");
            Console.SetCursorPosition(0, 5);
            Console.Write("│      ");
            Console.SetCursorPosition(0, 6);
            Console.Write("│     ");
            Console.SetCursorPosition(0, 7);
            Console.Write("│");
            Console.SetCursorPosition(0, 8);
            Console.Write("┴");

            for (x = 0; x < vTam; x++)
            {
                Console.SetCursorPosition(26 + x, 7);
                vAtual = vAtual + "-";

            }

            Console.Write(vAtual);

            do
            {



                Console.SetCursorPosition(0, 1);
                Console.Write("Digite uma letra: ");
                vletraD = Console.ReadLine();
                palavrajadigitada = vletraD;


                vPosicao = vPosicao + 4;
                vAnterior = vAtual;
                vAtual = "";
                vAcertou = false;

                Console.SetCursorPosition(25, 20);
                Console.Write("letras digitadas : ");

                Console.SetCursorPosition(vPosicao, 21);
                Console.Write(palavrajadigitada + " | ");










                for (x = 0; x < vTam; x++)
                {
                    vLetra = vpalavra.Substring(x, 1);
                    vLetraA = vAnterior.Substring(x, 1);
                    if ((vletraD == vLetra) && (vLetraA == "-"))
                    {

                        vAtual = vAtual + vLetra;
                        vAcertos = vAcertos + 1;
                        vAcertou = true;
                    }


                    else
                    {
                        vAtual = vAtual + vLetraA;
                    }

                }

                if (false == vAcertou)
                {
                    vErros = vErros + 1;
                    MostraCorpo(vErros);

                    Console.SetCursorPosition(20, 10);
                    Console.Write("Erros: ");

                    Console.SetCursorPosition(vPosicao, 11);
                    Console.Write(vletraD + " | ");

                }

                Console.SetCursorPosition(25 + x, 7);
                Console.Write(vAtual);

                if (vAcertos == vTam)
                {
                    Console.SetCursorPosition(25, 13);
                    Console.WriteLine("Parabéns, você ganhou !!!");
                }

                if (vErros == 6)
                {
                    Console.SetCursorPosition(25, 13);
                    Console.WriteLine(" Você perdeu !!!");
                    Console.SetCursorPosition(25, 14);
                    Console.WriteLine("A palavra era " + vpalavra);
                }
                if (palavrajadigitada.Contains(vLetraA))
                {
                    Console.SetCursorPosition(25, 5);
                    Console.Write("Você já digitou essa letra !!!");
                    Thread.Sleep(1000);
                    Console.SetCursorPosition(25, 5);
                    Console.Write("                              ");
                }

            } while ((vErros != 6) && (vAcertos != vTam));
            Console.ReadKey();
        }

        static void MostraCorpo(int p)
        {
            switch (p)
            {
                case 1:
                    {
                        Console.SetCursorPosition(7, 3);
                        Console.Write("O");
                    };
                    break;

                case 2:
                    {
                        Console.SetCursorPosition(6, 4);
                        Console.Write("┌");
                    };
                    break;

                case 3:
                    {
                        Console.SetCursorPosition(7, 4);
                        Console.Write("|");

                        Console.SetCursorPosition(7, 5);
                        Console.Write("|");
                    };
                    break;

                case 4:
                    {
                        Console.SetCursorPosition(8, 4);
                        Console.Write("┐");
                    };
                    break;

                case 5:
                    {
                        Console.SetCursorPosition(6, 6);
                        Console.Write("┘");
                    };
                    break;

                case 6:
                    {
                        Console.SetCursorPosition(8, 6);
                        Console.Write("└");
                    };
                    break;


            }
        }
        static void extenso()
        {
            {
                /*string[] unidade = new string[20];
                unidade [0] = "zero";*/

                string[] unidade = { "zero", "um", "dois",
                "três","quatro","Cinco","Seis","Sete","Oito","Nove","Dez","Onze","Doze","Treze","Quatorze","Quinze",
                "Dezesseis","Dezessete","Dezoito","Dezenove"};
                string[] dezena = { "", "", "Vinte", "Trinta","Quarenta","Cinquenta","Sessenta","Setenta","oitenta","Noventa",
                "Cento", "Duzentos", "Trezentos", "Quatrocentos", "Quinhentos", "Seiscentos", "Setecentos,", "Oitocentos", "Novecentos" };


                int n, nd, ne, nm, calculo;

                Console.Clear();

                Console.Write("Digite o número para ver por extenso: ");
                n = int.Parse(Console.ReadLine());

                if (n < 0 || n > 999)
                {
                    Console.WriteLine("Número inválido ");

                }

                else if (n < 20)
                {
                    Console.Write(unidade[n]);
                }
                else if (n == 100)
                {
                    Console.WriteLine("Cem");

                }
                else if (n < 100)
                {
                    ne = n / 10;
                    nd = n % 10;
                    Console.Write(dezena[ne]);
                    if (nd != 0)
                    {

                        Console.Write(unidade[nd]);
                    }
                }
                else if (n > 100)
                {
                    ne = n / 100;
                    ne = ne + 9;
                    Console.Write(dezena[ne]);
                    calculo = n % 100;
                    nd = calculo % 10;
                    nm = calculo / 10;
                    if (calculo < 20)
                    {
                        Console.Write(" e " + unidade[calculo]);
                    }
                    else
                    {
                        if (nm != 0)
                        {
                            Console.Write(" e " + dezena[nm]);
                        }
                        if (nd != 0)
                        {
                            Console.Write(" e " + unidade[nd]);
                        }
                    }
                }
                Console.ReadKey();

            }
        }
   
        

        static void janela(int L1, int C1, int L2, int C2)
        {
            int x;
            for (x = L1; x <= L2; x++)
            {
                Console.SetCursorPosition(C1, x); Console.Write("║");
                Console.SetCursorPosition(C2, x); Console.Write("║");
            }
            for (x = C1; x <= C2; x++)
            {
                Console.SetCursorPosition(x, L1); Console.Write("═");
                Console.SetCursorPosition(x, L2); Console.Write("═");
            }
            Console.SetCursorPosition(C1, L1); Console.Write("╔");
            Console.SetCursorPosition(C2, L1); Console.Write("╗");
            Console.SetCursorPosition(C1, L2); Console.Write("╚");
            Console.SetCursorPosition(C2, L2); Console.Write("╝");
        }
    

    }


}



